{
    'name': 'QZ Tray Odoo Fixed',
    'version': '18.0.1.0.0',
    'category': 'Tools',
    'summary': 'QZ Tray integration demo (fixed for Odoo 18)',
    'depends': ['base'],
    'data': [
        'views/views.xml',
    ],
    'installable': True,
    'application': False,
}
