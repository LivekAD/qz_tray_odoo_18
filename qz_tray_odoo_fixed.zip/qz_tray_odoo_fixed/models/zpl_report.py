from odoo import models, fields

class ZplReport(models.Model):
    _name = "zpl.report"
    _description = "ZPL Report"

    name = fields.Char(string="Report Name")

    def action_print_preview(self):
        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Print Preview (stub, works fine)',
                'type': 'rainbow_man',
            }
        }
