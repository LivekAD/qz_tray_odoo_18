from odoo import http
from odoo.http import request

class QZTrayController(http.Controller):
    @http.route('/qz_tray_odoo_18/print_raw', type='json', auth='user')
    def print_raw(self, data):
        # This is a placeholder endpoint that can be used to log or pre-process print jobs.
        # The actual printing to a local USB printer is done client-side via QZ Tray JS.
        # We return the same data back for client to use.
        return {'status': 'ok', 'data': data}
