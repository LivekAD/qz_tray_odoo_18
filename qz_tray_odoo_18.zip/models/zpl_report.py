from odoo import models, fields, api

class ZPLReport(models.Model):
    _name = "zpl.report"
    _description = "ZPL Print Template"

    name = fields.Char(required=True)
    model_id = fields.Many2one('ir.model', string='Model')
    field_id = fields.Many2one('ir.model.fields', string='Field', domain="[('model_id','=',model_id)]")
    variable = fields.Char(string='Variable')
    zpl_template = fields.Text(string='ZPL Template')
