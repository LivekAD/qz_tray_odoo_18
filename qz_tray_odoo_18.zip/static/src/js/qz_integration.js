odoo.define('qz_tray_odoo_18.qz', function(require){
    'use strict';
    var core = require('web.core');
    var rpc = require('web.rpc');
    var Dialog = require('web.Dialog');

    // Minimal QZ Tray integration helper
    var QZ = {
        isAvailable: function(){
            return typeof qz !== 'undefined';
        },
        printRaw: function(raw) {
            if(!this.isAvailable()){
                Dialog.alert(null, 'QZ Tray not found. Please install and run QZ Tray on your machine.');
                return;
            }
            // Example: create an array of data for qz.print
            var data = [ raw ];
            qz.print(qz.configs.create('default'), data).catch(function(e){ console.error(e); Dialog.alert(null, 'Print error: ' + e); });
        },
        connect: function(){
            if(this.isAvailable()){
                qz.websocket.connect().then(function(){ console.log('QZ connected'); }).catch(function(e){ console.error(e); });
            }
        }
    };

    // Expose to global for easy use in browser console / custom buttons
    window.OdooQZ = QZ;

    // Auto-connect on load
    $(function(){
        setTimeout(function(){ QZ.connect(); }, 1000);
    });

    return QZ;
});
