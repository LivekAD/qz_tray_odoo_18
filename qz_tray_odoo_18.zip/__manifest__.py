{
    "name": "QZ Tray Integration (Odoo 18)",
    "version": "18.0.1.0.0",
    "summary": "Simple QZ Tray integration and ZPL report scaffold for Odoo 18",
    "category": "Tools",
    "author": "ChatGPT",
    "license": "LGPL-3",
    "depends": ["base", "web", "product"],
    "data": [
        "security/ir.model.access.csv",
        "views/views.xml",
        "views/assets.xml"
    ],
    "assets": {
        "web.assets_backend": [
            "qz_tray_odoo_18/static/src/js/qz_integration.js"
        ]
    },
    "installable": True,
    "application": False
}
