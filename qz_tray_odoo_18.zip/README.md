QZ Tray Integration (Odoo 18)
----------------------------

This is a minimal scaffold module for Odoo 18 that provides:
- A simple model `zpl.report` for storing ZPL templates
- Backend JS that attempts to connect to QZ Tray (client-side)
- A controller endpoint that echoes print data (can be extended)

Installation:
1. Copy the module to your addons folder, e.g. /var/lib/odoo/.local/share/Odoo/addons/qz_tray_odoo_18
2. chown -R odoo:odoo qz_tray_odoo_18
3. Restart Odoo: systemctl restart odoo
4. Update Apps List and install "QZ Tray Integration (Odoo 18)"

Notes:
- The actual printing to USB via QZ Tray happens in the browser: install QZ Tray on the Windows machine,
  open Odoo in that browser, and QZ Tray JS will attempt to connect.
- This module is a scaffold — extend it with server-side print jobs, ESC/POS generation, etc., as needed.
